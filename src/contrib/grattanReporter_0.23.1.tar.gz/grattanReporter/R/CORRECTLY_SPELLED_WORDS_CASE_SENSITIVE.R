#' List of correctly spelled, case-sensitive words
#' @format A character vector of words as perl-regex case-sensitive patterns to skip during the spell check.

"grattan_CORRECTLY_SPELLED_WORDS_CASE_SENSITIVE"
