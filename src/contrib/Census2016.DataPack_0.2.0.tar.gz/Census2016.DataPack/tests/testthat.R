library(testthat)
library(Census2016.DataPack)

test_check("Census2016.DataPack")
