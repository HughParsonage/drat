#' @title ISO3166 decoder
#' @description Countries with the alpha-2 and alpha-3 codes.
"ISO3166"
