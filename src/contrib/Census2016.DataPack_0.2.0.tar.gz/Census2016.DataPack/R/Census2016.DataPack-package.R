#' Census 2016 package
#' @description Data packs from the 2016 Australian Census.
#' @import data.table
#' @importFrom stats weighted.mean
#' @keywords internal
"_PACKAGE"
