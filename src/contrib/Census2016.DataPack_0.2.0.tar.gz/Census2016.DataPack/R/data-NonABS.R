#' NonABS_decoder
#' @description Decoder for the non-ABS geographic data structures, includign the area.
#' @details Variable names may change without notice.
"NonABS_decoder"

