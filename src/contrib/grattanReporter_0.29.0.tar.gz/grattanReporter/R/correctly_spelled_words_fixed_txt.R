#' List of correctly spelled words
#' @format A character vector of words as fixed words to skip during the spell check.

"correctly_spelled_words_fixed_txt"
