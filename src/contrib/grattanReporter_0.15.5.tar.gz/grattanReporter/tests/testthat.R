library(testthat)
library(grattanReporter)

test_check("grattanReporter")
