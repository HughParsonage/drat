# Census2016.DataPack 0.1.9

* Remove SA1, SSC large portions. These data tables will be part of a new package.
* `IncomeTotPersonal.min` removed in preference of `.max`. 
* Indigenous age groups and age groups of mothers in children ever born table changed to `Age5yr` to reflect the different levels.
