# TeXCheckR

Development page for TeXCheckR. See also https://github.com/hughparsonage/grattanReporter 
