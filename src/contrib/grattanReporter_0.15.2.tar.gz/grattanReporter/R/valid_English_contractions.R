#' Valid English contractions
#' @description List of words which should never raise a spelling error.
#' @source https://gist.githubusercontent.com/J3RN/ed7b420a6ea1d5bd6d06/raw/acda66b325a2b4d7282fb602a7551912cdc81e74/contractions.txt

"valid_English_contractions"
