

inputs_of <- function(filename, append.tex = TRUE){
  TeXCheckR::inputs_of(filename, append.tex = append.tex)
}
