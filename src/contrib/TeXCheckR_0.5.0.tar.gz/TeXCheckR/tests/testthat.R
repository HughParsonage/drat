library(testthat)
library(TeXCheckR)

test_check("TeXCheckR")
