context("inputs")

test_that("Simple input works", {
  expect_null(checkGrattanReport("./SF-input"))
})
