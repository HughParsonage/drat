#' Get the object containing all sample files
#' 
#' @return A promise to \code{sample_files_all}. See \code{?sample_files}.
#' @import data.table
#' @export

get_sample_files_all <- function(){
  if (!"package:data.table" %in% search()){
    stop("Attach the data.table package.")
  } else {
    delayedAssign("sample_files_all", 
                  {
                    adt <- function(...) data.table::as.data.table(...)
                    
                    sample_file_0304 <- NULL # (2004)
                    sample_file_0405 <- NULL # (2005)
                    sample_file_0506 <- NULL # (2006)
                    sample_file_0607 <- NULL # (2007)
                    sample_file_0708 <- NULL # (2008)
                    sample_file_0809 <- NULL # (2009)
                    sample_file_0910 <- NULL # (2010)
                    sample_file_1011 <- NULL # (2011)
                    sample_file_1112 <- NULL # (2012)
                    sample_file_1213 <- NULL # (2013)
                    sample_file_1314 <- NULL
                    
                    fy.year <- NULL
                    WEIGHT <- NULL
                    
                    sample_files_all <- data.table::rbindlist(list("2003-04"  = adt(sample_file_0304),  # <-get_sample_file(2004)
                                                                   "2004-04"  = adt(sample_file_0405),  # <-get_sample_file(2005)
                                                                   "2005-04"  = adt(sample_file_0506),  # <-get_sample_file(2006)
                                                                   "2006-04"  = adt(sample_file_0607),  # <-get_sample_file(2007)
                                                                   "2007-04"  = adt(sample_file_0708),  # <-get_sample_file(2008)
                                                                   "2008-04"  = adt(sample_file_0809),  # <-get_sample_file(2009)
                                                                   "2009-04"  = adt(sample_file_0910),  # <-get_sample_file(2010)
                                                                   "2010-04"  = adt(sample_file_1011),  # <-get_sample_file(2011)
                                                                   "2011-04"  = adt(sample_file_1112),  # <-get_sample_file(2012)
                                                                   "2012-04"  = adt(sample_file_1213),  # <-get_sample_file(2013))
                                                                   "2013-14"  = adt(sample_file_1314)
                    ), use.names = TRUE, fill = TRUE, idcol = "fy.year")
                    sample_files_all[, WEIGHT := dplyr::if_else(fy.year > "2010-11", 50L, 100L)]
                    sample_files_all
                  })
  }
}
