
.onAttach <-function(libname = find.package("taxstats"), pkgname = "taxstats"){
  NULL
}

